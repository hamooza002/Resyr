<?php

namespace App\Repository;

interface ReservationRepositoryInterface extends BaseRepositoryInterface {}