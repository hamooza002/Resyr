<?php

namespace App\Repository;

interface SettingRepositoryInterface extends BaseRepositoryInterface {}