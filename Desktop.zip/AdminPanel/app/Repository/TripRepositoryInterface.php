<?php

namespace App\Repository;

interface TripRepositoryInterface extends BaseRepositoryInterface {}