<?php

namespace App\Repository;

interface DriverDocumentRepositoryInterface extends BaseRepositoryInterface {}

