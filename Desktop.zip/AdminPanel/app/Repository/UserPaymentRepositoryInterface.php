<?php

namespace App\Repository;

interface UserPaymentRepositoryInterface extends BaseRepositoryInterface {}

