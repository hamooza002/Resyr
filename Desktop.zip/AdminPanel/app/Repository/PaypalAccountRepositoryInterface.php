<?php

namespace App\Repository;

interface PaypalAccountRepositoryInterface extends BaseRepositoryInterface {}

