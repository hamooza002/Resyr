<?php

namespace App\Repository;

interface CouponCustomerRepositoryInterface extends BaseRepositoryInterface {}

