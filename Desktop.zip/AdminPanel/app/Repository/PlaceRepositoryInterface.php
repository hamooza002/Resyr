<?php

namespace App\Repository;

interface PlaceRepositoryInterface extends BaseRepositoryInterface {}

