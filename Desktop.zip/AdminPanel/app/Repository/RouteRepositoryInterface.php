<?php

namespace App\Repository;

interface RouteRepositoryInterface extends BaseRepositoryInterface {}