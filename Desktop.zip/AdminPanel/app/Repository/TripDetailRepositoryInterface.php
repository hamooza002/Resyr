<?php

namespace App\Repository;

interface TripDetailRepositoryInterface extends BaseRepositoryInterface {}