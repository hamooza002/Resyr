<?php

namespace App\Repository;

interface ComplaintRepositoryInterface extends BaseRepositoryInterface {}

