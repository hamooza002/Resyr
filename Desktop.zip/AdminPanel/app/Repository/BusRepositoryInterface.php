<?php

namespace App\Repository;

interface BusRepositoryInterface extends BaseRepositoryInterface {}