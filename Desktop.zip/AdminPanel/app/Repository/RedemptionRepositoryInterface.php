<?php

namespace App\Repository;

interface RedemptionRepositoryInterface extends BaseRepositoryInterface {}

