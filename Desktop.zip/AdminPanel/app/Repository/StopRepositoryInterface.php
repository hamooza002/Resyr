<?php

namespace App\Repository;

interface StopRepositoryInterface extends BaseRepositoryInterface {}