<?php

namespace App\Repository;

interface MobileMoneyAccountRepositoryInterface extends BaseRepositoryInterface {}

