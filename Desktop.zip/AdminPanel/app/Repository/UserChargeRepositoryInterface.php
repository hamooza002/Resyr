<?php

namespace App\Repository;

interface UserChargeRepositoryInterface extends BaseRepositoryInterface {}

