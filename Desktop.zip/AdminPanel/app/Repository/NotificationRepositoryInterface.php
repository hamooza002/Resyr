<?php

namespace App\Repository;

interface NotificationRepositoryInterface extends BaseRepositoryInterface {}

