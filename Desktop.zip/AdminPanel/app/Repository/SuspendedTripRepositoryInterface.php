<?php

namespace App\Repository;

interface SuspendedTripRepositoryInterface extends BaseRepositoryInterface {}