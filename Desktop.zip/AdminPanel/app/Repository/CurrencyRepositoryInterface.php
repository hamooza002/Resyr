<?php

namespace App\Repository;

interface CurrencyRepositoryInterface extends BaseRepositoryInterface {}