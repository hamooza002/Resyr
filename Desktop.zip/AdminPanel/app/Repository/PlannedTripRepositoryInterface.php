<?php

namespace App\Repository;

interface PlannedTripRepositoryInterface extends BaseRepositoryInterface {}

