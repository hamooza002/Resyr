<?php

namespace App\Repository;

interface UserRefundRepositoryInterface extends BaseRepositoryInterface {}

