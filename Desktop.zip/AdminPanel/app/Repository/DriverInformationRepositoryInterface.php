<?php

namespace App\Repository;

interface DriverInformationRepositoryInterface extends BaseRepositoryInterface {}

