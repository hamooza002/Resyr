<?php

namespace App\Repository;

interface RouteStopDirectionRepositoryInterface extends BaseRepositoryInterface {}