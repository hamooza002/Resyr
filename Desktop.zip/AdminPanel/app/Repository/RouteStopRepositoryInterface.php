<?php

namespace App\Repository;

interface RouteStopRepositoryInterface extends BaseRepositoryInterface {}