<?php

namespace App\Repository;

interface BankAccountRepositoryInterface extends BaseRepositoryInterface {}

