<?php

namespace App\Repository;

interface TripSearchResultRepositoryInterface extends BaseRepositoryInterface {}

